import tkinter as tk
from tkinter import scrolledtext, messagebox

# Basit Türkçe dil yorumlayıcı
def yorumla(kod):
    satırlar = kod.strip().split("\n")
    değişkenler = {}
    çıktı = ""

    for satır in satırlar:
        satır = satır.strip()

        # yazdır
        if satır.startswith("yazdır(") and satır.endswith(")"):
            içerik = satır[7:-1]
            try:
                içerik = eval(içerik, {}, değişkenler)
            except:
                içerik = içerik.strip('"')
            çıktı += str(içerik) + "\n"

        # değişken tanımı
        elif satır.startswith("değişken "):
            try:
                _, kalan = satır.split("değişken ", 1)
                ad, değer = kalan.split(" = ")
                değişkenler[ad.strip()] = eval(değer.strip(), {}, değişkenler)
            except Exception as e:
                çıktı += f"HATA: Değişken tanımlanamadı -> {e}\n"

        # toplama
        elif satır.startswith("topla(") and satır.endswith(")"):
            try:
                argümanlar = satır[6:-1].split(",")
                toplam = sum(eval(a.strip(), {}, değişkenler) for a in argümanlar)
                çıktı += f"{toplam}\n"
            except:
                çıktı += "HATA: topla() kullanımı yanlış.\n"

        # çıkarma
        elif satır.startswith("çıkar(") and satır.endswith(")"):
            try:
                argümanlar = satır[7:-1].split(",")
                sonuc = eval(argümanlar[0].strip(), {}, değişkenler)
                for a in argümanlar[1:]:
                    sonuc -= eval(a.strip(), {}, değişkenler)
                çıktı += f"{sonuc}\n"
            except:
                çıktı += "HATA: çıkar() kullanımı yanlış.\n"

        # eğer
        elif satır.startswith("eğer "):
            try:
                şart, komut = satır[5:].split(" ise ")
                if eval(şart.strip(), {}, değişkenler):
                    çıktı += yorumla(komut.strip())
            except:
                çıktı += "HATA: eğer...ise kullanımı yanlış.\n"

        # değilse
        elif satır.startswith("değilse "):
            try:
                komut = satır[8:].strip()
                çıktı += yorumla(komut)
            except:
                çıktı += "HATA: değilse kullanımı yanlış.\n"

        elif satır == "":
            continue
        else:
            çıktı += f"Bilinmeyen komut: {satır}\n"

    return çıktı

# Arayüz başlat
def çalıştır():
    kod = metin_kutusu.get("1.0", tk.END)
    çıktı = yorumla(kod)
    çıktı_kutusu.config(state='normal')
    çıktı_kutusu.delete("1.0", tk.END)
    çıktı_kutusu.insert(tk.END, çıktı)
    çıktı_kutusu.config(state='disabled')

# Pencere oluştur
pencere = tk.Tk()
pencere.title("Türkçe Kod Editörü")
pencere.geometry("800x600")
pencere.configure(bg="#1e1e1e")

# Kod yazma alanı
etiket = tk.Label(pencere, text="Kodunu Yaz:", bg="#1e1e1e", fg="white")
etiket.pack()

metin_kutusu = scrolledtext.ScrolledText(pencere, wrap=tk.WORD, width=100, height=20, bg="#252526", fg="white", insertbackground='white')
metin_kutusu.pack(padx=10, pady=10)

# Çalıştır butonu
buton = tk.Button(pencere, text="Çalıştır", command=çalıştır, bg="#0e639c", fg="white", font=("Arial", 12))
buton.pack(pady=5)

# Çıktı alanı
etiket2 = tk.Label(pencere, text="Çıktı:", bg="#1e1e1e", fg="white")
etiket2.pack()

çıktı_kutusu = scrolledtext.ScrolledText(pencere, wrap=tk.WORD, width=100, height=10, bg="#1e1e1e", fg="#dcdcaa", state='disabled')
çıktı_kutusu.pack(padx=10, pady=10)

pencere.mainloop()
