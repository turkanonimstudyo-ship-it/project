
import tkinter as tk
import random

def veri_uret():
    algoritmalar = {}

    # Günlük konuşma örnekleri
    gunluk_cevaplar = [
        "İyiyim, teşekkür ederim!",
        "Harikayım, sen nasılsın?",
        "Bugün hava çok güzel!",
        "Enerjim yerinde, sen nasılsın?",
        "Şu an biraz meşgulüm ama iyiyim.",
    ]

    # Yazılım örnek cevapları
    yazilim_cevaplar = [
        "liste = [1, 2, 3, 4]",
        "def fonksiyon():\n    print('Merhaba')",
        "<button>Bas Bana</button>",
        "alert('Merhaba Dünya!');",
        "SELECT * FROM kullanicilar WHERE aktif=1;",
    ]

    # Termux komutları
    termux_komutlar = [
        "pkg update && pkg install nmap",
        "pkg install unstable-repo && pkg install metasploit",
        "pkg install python && pip install sqlmap",
        "pkg install hydra",
        "wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip && unzip ngrok-stable-linux-arm.zip",
    ]

    for i in range(1, 401):
        algoritmalar[f"selam{i}"] = gunluk_cevaplar

    for i in range(401, 701):
        algoritmalar[f"yazilim{i}"] = yazilim_cevaplar

    for i in range(701, 1001):
        algoritmalar[f"termux{i}"] = termux_komutlar

    # Özel anahtarlar
    algoritmalar["ağla"] = [
        "Seni gidi beta, ağlamalısın!",
        "Ağla kardeşşş, dünya dertli.",
        "Ağlamak bazen iyidir, sal!",
    ]
    algoritmalar["python"] = [
        "Python çok güçlü bir programlama dilidir.",
        "Python ile neler yapabileceğini hayal et!",
    ]
    algoritmalar["çık"] = ["Görüşürüz, kendine iyi bak!"]

    # Çok kullanılan kelimelerden birkaç örnek daha
    algoritmalar["selam"] = ["Selamünaleyküm kardeşim!", "Aleyküm selam reis.", "Hoş geldin!"]
    algoritmalar["nasılsın"] = ["İyiyim, teşekkür ederim.", "Harikayım, sen nasılsın?"]

    return algoritmalar

algoritmalar = veri_uret()

def algoritma_cevap(mesaj):
    mesaj = mesaj.lower()
    kelimeler = mesaj.split()
    for kelime in kelimeler:
        for anahtar in algoritmalar.keys():
            if anahtar in kelime or kelime in anahtar:
                cevaplar = algoritmalar[anahtar]
                return random.choice(cevaplar) if isinstance(cevaplar, list) else cevaplar
    return "Üzgünüm, bunu şu an cevaplayamıyorum."

def gonder():
    kullanici_mesaji = giris.get()
    if not kullanici_mesaji.strip():
        return
    yanit = algoritma_cevap(kullanici_mesaji)
    sohbet.insert(tk.END, f"Sen: {kullanici_mesaji}\n")
    sohbet.insert(tk.END, f"AzadZeka: {yanit}\n\n")
    sohbet.see(tk.END)
    giris.delete(0, tk.END)
    if "çık" in kullanici_mesaji.lower():
        pencere.after(1000, pencere.destroy)

pencere = tk.Tk()
pencere.title("AzadZeka +1000 Algoritma")
pencere.geometry("520x450")
pencere.config(bg="#222222")

sohbet = tk.Text(pencere, bg="#111111", fg="#eeeeee", font=("Consolas", 12))
sohbet.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

giris = tk.Entry(pencere, font=("Consolas", 14))
giris.pack(padx=10, pady=(0,10), fill=tk.X)
giris.focus()

buton = tk.Button(pencere, text="Gönder", font=("Consolas", 12), command=gonder, bg="#00aaff", fg="white")
buton.pack(padx=10, pady=(0,10), fill=tk.X)

giris.bind("<Return>", lambda e: gonder())

sohbet.insert(tk.END, "AzadZeka: Selam! Bana bir şey sorabilirsin. Çıkmak için 'çık' yaz.\n\n")

pencere.mainloop()
