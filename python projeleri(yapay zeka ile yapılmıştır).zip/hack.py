import time

alphabet = "abcçdefgğhıijklmnoöprsştuüvyzABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ0123456789_-?!/*|<>.:,;£%½+$&^#=~¨"

user_password = input("Kırılacak Şifreyi Girin: ")
length = len(user_password)

crack = [''] * length

total_attempts = 0

placeholder = alphabet[0]

delay = 0.01

for pos in range(length - 1, -1, -1):
    local_attempts = 0
    for char in alphabet:
        local_attempts += 1
        total_attempts += 1

        candidate = []
        for i in range(length):
            if crack[i] != '':
                candidate.append(crack[i])
            elif i == pos:
                candidate.append(char)
            else:
                candidate.append(placeholder)
        candidate_str = ''.join(candidate)

        print(candidate_str)
        time.sleep(delay)

        if char == user_password[pos]:
            crack[pos] = char
            print("Pozisyon {} Bulundu: '{}' (Bu Harf {} Şifre Denenerek Bulundu)".format(pos, char, local_attempts))
            break

final_password = ''.join(crack)
print("Şifre Bulundu: " + final_password)
print("Toplam Denenen Şifre: " + str(total_attempts))