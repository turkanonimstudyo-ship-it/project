import tkinter as tk
import tkinter.simpledialog as simpledialog
import tkinter.messagebox
import urllib.request, urllib.error
from html.parser import HTMLParser
import os, re
import webbrowser  # jsfs.html açmak için

KLASOR = "osmanlios_dosyalar"
os.makedirs(KLASOR, exist_ok=True)

# ---------- Basit HTML’den düz metin çıkarıcı ----------

class MetinAyiklayici(HTMLParser):
    """<p>, <h1-6>, <li> ve <br> etiketlerindeki metni toplar."""
    def __init__(self):
        super().__init__()
        self.buf, self._kaydet = [], False

    def handle_starttag(self, tag, attrs):
        if tag in ("p", "li") or tag.startswith("h"):
            self._kaydet = True
        if tag == "br":
            self.buf.append("\n")

    def handle_endtag(self, tag):
        if tag in ("p", "li") or tag.startswith("h"):
            self.buf.append("\n\n")
            self._kaydet = False

    def handle_data(self, data):
        if self._kaydet:
            temiz = re.sub(r"\s+", " ", data).strip()
            if temiz:
                self.buf.append(temiz + " ")

    def metin(self):
        return "".join(self.buf).strip()


# ---------- Tema ----------

def tema_yukle(dosya="tema.txt"):
    tema = {"arkaplan": "#fff8f0", "yazi_rengi": "#000000",
            "buton_renk": "#dddddd", "buton_yazi": "#000000", "font": "Arial"}
    if os.path.exists(dosya):
        with open(dosya, encoding="utf-8") as f:
            for s in f:
                if "=" in s:
                    k, v = s.strip().split("=", 1)
                    tema[k.strip()] = v.strip()
    return tema

tema = tema_yukle()


# ---------- Terminal (değişmedi) ----------

def terminal_cevapla(komut, output):
    komut = komut.strip().lower()
    if komut == "sudo su":
        cevap = "Yönetici moduna geçildi."
    elif komut == "sudo apt upgrade":
        cevap = "Sistem güncelleniyor... Tamamlandı."
    elif komut == "sudo apt install sohbet":
        cevap = "Sohbet modülü yüklendi."
    elif komut == "selam":
        cevap = "Aleyküm selam, kullanıcı!"
    elif komut == "yardım":
        cevap = ("Komutlar: sudo su, sudo apt upgrade, "
                 "sudo apt install sohbet, selam, yardım, temizle")
    elif komut == "temizle":
        output.delete("1.0", tk.END)
        return
    else:
        cevap = f'"{komut}" komutu tanınmıyor.'
    output.insert(tk.END, f"> {komut}\n{cevap}\n\n")
    output.see(tk.END)

def terminal_ac():
    win = tk.Toplevel()
    win.title("💻 OsmanlıOS Terminal")
    out = tk.Text(win, bg="black", fg="lime", height=20, width=60)
    out.pack()
    inp = tk.Entry(win, bg="black", fg="white", width=60)
    inp.pack()
    inp.bind("<Return>", lambda e=None: (terminal_cevapla(inp.get(), out), inp.delete(0, tk.END)))


# ---------- Dosya Yöneticisi (değişmedi) ----------

def dosya_yoneticisi_ac():
    win = tk.Toplevel()
    win.title("📁 Dosya Yöneticisi")
    win.configure(bg=tema["arkaplan"])
    liste = tk.Listbox(win, width=50)
    liste.pack()
    for dosya in os.listdir(KLASOR):
        liste.insert(tk.END, dosya)

    def oku():
        if sec := liste.curselection():
            yol = os.path.join(KLASOR, liste.get(sec))
            with open(yol, "r", encoding="utf-8", errors="ignore") as f:
                icerik = f.read()
            y = tk.Toplevel()
            y.title(os.path.basename(yol))
            t = tk.Text(y, wrap="word")
            t.insert(tk.END, icerik)
            t.pack()

    def olustur():
        if yeni := simpledialog.askstring("Yeni Dosya", "Dosya adı gir:"):
            yol = os.path.join(KLASOR, yeni)
            try:
                open(yol, "w").close()
                liste.insert(tk.END, yeni)
            except Exception as e:
                tk.messagebox.showerror("Hata", str(e))

    tk.Button(win, text="Dosyayı Aç", command=oku,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack()
    tk.Button(win, text="Yeni Dosya Oluştur", command=olustur,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack()


# ---------- Terminal-tarzı Gömülü Tarayıcı ----------

def tarayici_ac():
    win = tk.Toplevel()
    win.title("🕸 OsmanlıOS Metin Tarayıcı")
    win.geometry("700x500")
    url_box = tk.Entry(win, width=80)
    url_box.pack(pady=5)
    url_box.insert(0, "https://")
    metin = tk.Text(win, wrap="word", bg="white")
    metin.pack(expand=True, fill="both")

    def getir():
        url = url_box.get().strip()
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        metin.delete("1.0", tk.END)
        try:
            with urllib.request.urlopen(url, timeout=10) as r:
                html = r.read().decode(errors="ignore")
            p = MetinAyiklayici()
            p.feed(html)
            icerik = p.metin() or "[!] Metin bulunamadı veya sayfa çok karmaşık."
        except urllib.error.URLError as e:
            icerik = f"Hata: {e.reason}"
        except Exception as e:
            icerik = f"Hata: {e}"
        metin.insert(tk.END, icerik)

    tk.Button(win, text="Getir", command=getir,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack(pady=5)


# ---------- jsfs.html dosyasını sistem varsayılan tarayıcıda açan fonksiyon ----------

def html_dosyasi_ac():
    dosya_yolu = os.path.abspath(os.path.join(KLASOR, "jsfs.html"))
    if os.path.exists(dosya_yolu):
        webbrowser.open(f"file:///{dosya_yolu}")
    else:
        tk.messagebox.showerror("Hata", f"{dosya_yolu} bulunamadı.")


# ---------- Masaüstü ----------

def masaustu():
    root = tk.Tk()
    root.title("👑 OsmanlıOS Masaüstü")
    root.geometry("600x400")
    root.configure(bg=tema["arkaplan"])

    tk.Label(root, text="👑 OsmanlıOS'a Hoş Geldiniz",
             font=(tema["font"], 16), bg=tema["arkaplan"], fg=tema["yazi_rengi"]).pack(pady=20)

    tk.Button(root, text="💻 Terminal", command=terminal_ac, width=30,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack(pady=5)
    tk.Button(root, text="📁 Dosya Yöneticisi", command=dosya_yoneticisi_ac, width=30,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack(pady=5)
    tk.Button(root, text="🕸 Metin Tarayıcı", command=tarayici_ac, width=30,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack(pady=5)

    # --- jsfs.html gösterme butonu eklendi ---
    tk.Button(root, text="🖥 jsfs.html Göster", command=html_dosyasi_ac, width=30,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack(pady=5)

    tk.Button(root, text="Çıkış", command=root.quit, width=30,
              bg=tema["buton_renk"], fg=tema["buton_yazi"]).pack(pady=20)

    root.mainloop()

# ---------- Başlat ----------

masaustu()
